export const LANGUAGES = [
  { code: 'en', name: 'English',           native: 'English',    speechCode: 'en-IN' },
  { code: 'hi', name: 'Hindi',             native: 'हिन्दी',        speechCode: 'hi-IN' },
  { code: 'mr', name: 'Marathi',           native: 'मराठी',         speechCode: 'mr-IN' },
  { code: 'pa', name: 'Punjabi',           native: 'ਪੰਜਾਬੀ',        speechCode: 'pa-IN' },
  { code: 'te', name: 'Telugu',            native: 'తెలుగు',        speechCode: 'te-IN' },
  { code: 'ta', name: 'Tamil',             native: 'தமிழ்',         speechCode: 'ta-IN' },
  { code: 'kn', name: 'Kannada',           native: 'ಕನ್ನಡ',         speechCode: 'kn-IN' },
  { code: 'gu', name: 'Gujarati',          native: 'ગુજરાતી',       speechCode: 'gu-IN' },
  { code: 'bn', name: 'Bengali',           native: 'বাংলা',         speechCode: 'bn-IN' },
  { code: 'or', name: 'Odia',             native: 'ଓଡ଼ିଆ',          speechCode: 'or-IN' },
  { code: 'ml', name: 'Malayalam',         native: 'മലയാളം',        speechCode: 'ml-IN' },
];

export const QUICK_QUESTIONS = [
  { icon: '🌾', text: 'What fertilizer should I use for wheat in winter?' },
  { icon: '🍅', text: 'My tomato leaves are turning yellow and curling. What disease is this?' },
  { icon: '💧', text: 'What is the best irrigation schedule for rice paddy?' },
  { icon: '🌿', text: 'How do I control pests in my cotton crop organically?' },
  { icon: '🌱', text: 'What crops are best for sandy soil in dry climate?' },
  { icon: '🏛️', text: 'Government schemes for small farmers in India 2025?' },
];
