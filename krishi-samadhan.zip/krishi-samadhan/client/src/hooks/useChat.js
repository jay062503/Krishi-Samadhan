import { useState, useCallback } from 'react';
import api from '../utils/api';
import toast from 'react-hot-toast';

export function useChat(language, location) {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);

  const loadHistory = useCallback(async () => {
    try {
      const { data } = await api.get('/chat/history');
      setMessages(data.messages || []);
    } catch {}
  }, []);

  const sendMessage = useCallback(
    async (text, imageBase64 = null, imageMediaType = null) => {
      if (!text && !imageBase64) return;

      // Optimistic user message
      const userMsg = {
        role: 'user',
        displayText: text || '[Image uploaded for analysis]',
        hasImage: !!imageBase64,
        timestamp: new Date().toISOString(),
      };
      setMessages((prev) => [...prev, userMsg]);
      setLoading(true);

      try {
        const { data } = await api.post('/chat/message', {
          message: text,
          language,
          location,
          imageBase64,
          imageMediaType,
        });

        const botMsg = {
          role: 'assistant',
          displayText: data.reply,
          timestamp: new Date().toISOString(),
        };
        setMessages((prev) => [...prev, botMsg]);
      } catch (err) {
        toast.error(err.response?.data?.message || 'Failed to get response. Try again.');
        setMessages((prev) => prev.slice(0, -1)); // remove optimistic msg
      } finally {
        setLoading(false);
      }
    },
    [language, location]
  );

  const clearHistory = useCallback(async () => {
    await api.delete('/chat/history');
    setMessages([]);
    toast.success('Conversation cleared.');
  }, []);

  return { messages, loading, sendMessage, loadHistory, clearHistory };
}
