import React, { useState, useEffect, useRef } from 'react';
import './ChatPage.css';
import Header from '../components/Header';
import Sidebar from '../components/Sidebar';
import MessageBubble from '../components/MessageBubble';
import ChatInput from '../components/ChatInput';
import { useChat } from '../hooks/useChat';
import { useAuth } from '../context/AuthContext';

const LANG_CHIPS = ['हिन्दी','मराठी','ਪੰਜਾਬੀ','తెలుగు','தமிழ்','ಕನ್ನಡ','ગુજરાતી','বাংলা','ଓଡ଼ିଆ','English'];

export default function ChatPage() {
  const { user, updatePrefs } = useAuth();
  const [language, setLanguage] = useState(user?.preferredLanguage || 'en');
  const [location, setLocation]   = useState(user?.location || '');
  const { messages, loading, sendMessage, loadHistory, clearHistory } = useChat(language, location);
  const bottomRef = useRef(null);

  useEffect(() => { loadHistory(); }, [loadHistory]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const handleLanguageChange = (lang) => {
    setLanguage(lang);
    updatePrefs(lang, location).catch(() => {});
  };

  const handleLocationChange = (loc) => {
    setLocation(loc);
  };

  const handleSend = (text, imageBase64, imageMediaType) => {
    // Persist location prefs silently
    updatePrefs(language, location).catch(() => {});
    sendMessage(text, imageBase64, imageMediaType);
  };

  return (
    <div className="chat-page">
      <Header language={language} onLanguageChange={handleLanguageChange} />

      <div className="chat-body">
        <Sidebar
          location={location}
          onLocationChange={handleLocationChange}
          onQuickQuestion={(q) => handleSend(q, null, null)}
          onClear={clearHistory}
        />

        <div className="chat-main">
          <div className="chat-messages">
            {messages.length === 0 && (
              <div className="welcome-banner">
                <h2>🌾 Namaste, Kisan!</h2>
                <p>
                  Your intelligent agricultural assistant is ready.<br />
                  Ask questions about crops, soil, weather, pests, schemes — in your own language.
                </p>
                <div className="welcome-chips">
                  {LANG_CHIPS.map((c) => (
                    <span key={c} className="welcome-chip">{c}</span>
                  ))}
                </div>
              </div>
            )}

            {messages.map((msg, i) => (
              <MessageBubble key={i} message={msg} />
            ))}

            {loading && (
              <div className="msg-row bot" style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                <div className="msg-avatar" style={{ width:32, height:32, borderRadius:'50%', background:'var(--green-700)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:16 }}>🌱</div>
                <div style={{ background:'rgba(255,255,255,0.92)', borderRadius:14, borderBottomLeftRadius:4, padding:'10px 16px' }}>
                  <div className="typing-dots">
                    <span /><span /><span />
                  </div>
                </div>
              </div>
            )}

            <div ref={bottomRef} />
          </div>

          <ChatInput onSend={handleSend} loading={loading} language={language} />
        </div>
      </div>
    </div>
  );
}
