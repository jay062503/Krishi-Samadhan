import React, { useState, useRef } from 'react';
import './ChatInput.css';
import { LANGUAGES } from '../utils/languages';
import toast from 'react-hot-toast';

export default function ChatInput({ onSend, loading, language }) {
  const [text, setText] = useState('');
  const [pendingImages, setPendingImages] = useState([]);
  const [recording, setRecording] = useState(false);
  const fileRef = useRef(null);
  const textareaRef = useRef(null);
  const recognitionRef = useRef(null);

  const autoResize = (el) => {
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 120) + 'px';
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleSend = () => {
    if (!text.trim() && pendingImages.length === 0) return;
    const img = pendingImages[0];
    onSend(text.trim(), img?.base64 || null, img?.mediaType || null);
    setText('');
    setPendingImages([]);
    if (textareaRef.current) textareaRef.current.style.height = 'auto';
  };

  const handleImageUpload = (e) => {
    Array.from(e.target.files).forEach((file) => {
      const reader = new FileReader();
      reader.onload = (ev) => {
        const dataUrl = ev.target.result;
        setPendingImages((prev) => [
          ...prev,
          { base64: dataUrl.split(',')[1], mediaType: file.type, previewUrl: dataUrl },
        ]);
      };
      reader.readAsDataURL(file);
    });
    e.target.value = '';
  };

  const startVoice = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) { toast.error('Voice input not supported in this browser.'); return; }

    if (recording) {
      recognitionRef.current?.stop();
      setRecording(false);
      return;
    }

    const lang = LANGUAGES.find((l) => l.code === language);
    const recognition = new SpeechRecognition();
    recognition.lang = lang?.speechCode || 'en-IN';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => { setRecording(true); toast('Listening…', { icon: '🎙️' }); };
    recognition.onresult = (e) => {
      const transcript = e.results[0][0].transcript;
      setText((prev) => (prev ? prev + ' ' + transcript : transcript));
    };
    recognition.onerror = () => { toast.error('Voice error. Please try again.'); setRecording(false); };
    recognition.onend = () => setRecording(false);

    recognitionRef.current = recognition;
    recognition.start();
  };

  return (
    <div className="input-bar">
      {pendingImages.length > 0 && (
        <div className="image-preview-row">
          {pendingImages.map((img, i) => (
            <div key={i} className="img-thumb">
              <img src={img.previewUrl} alt="preview" />
              <button
                className="img-thumb-remove"
                onClick={() => setPendingImages((prev) => prev.filter((_, j) => j !== i))}
              >
                ✕
              </button>
            </div>
          ))}
        </div>
      )}

      <div className="input-row">
        <div className="input-side-btns">
          <button className="action-btn" title="Attach image" onClick={() => fileRef.current.click()}>
            📷
          </button>
          <button
            className={`action-btn ${recording ? 'recording' : ''}`}
            title="Voice input"
            onClick={startVoice}
          >
            🎙️
          </button>
        </div>

        <textarea
          ref={textareaRef}
          className="chat-textarea"
          rows={1}
          placeholder="Ask about crops, soil, pests, weather… (any language)"
          value={text}
          onChange={(e) => { setText(e.target.value); autoResize(e.target); }}
          onKeyDown={handleKeyDown}
          disabled={loading}
        />

        <button className="send-btn" onClick={handleSend} disabled={loading || (!text.trim() && pendingImages.length === 0)}>
          {loading ? '⏳' : '➤'}
        </button>
      </div>

      <input ref={fileRef} type="file" accept="image/*" multiple style={{ display: 'none' }} onChange={handleImageUpload} />
    </div>
  );
}
