import React from 'react';
import './Sidebar.css';
import { QUICK_QUESTIONS } from '../utils/languages';

export default function Sidebar({ location, onLocationChange, onQuickQuestion, onClear }) {
  return (
    <aside className="sidebar">
      <div>
        <div className="sidebar-section-title">Quick Questions</div>
        {QUICK_QUESTIONS.map((q, i) => (
          <button key={i} className="quick-btn" onClick={() => onQuickQuestion(q.text)}>
            <span className="quick-btn-icon">{q.icon}</span>
            <span>{q.text}</span>
          </button>
        ))}
      </div>

      <div>
        <div className="sidebar-section-title">Your Location</div>
        <input
          className="loc-input"
          type="text"
          placeholder="e.g. Pune, Maharashtra"
          value={location}
          onChange={(e) => onLocationChange(e.target.value)}
        />
      </div>

      <div>
        <div className="sidebar-section-title">Conversation</div>
        <button className="clear-btn" onClick={onClear}>🗑 Clear History</button>
      </div>

      <div>
        <div className="sidebar-section-title">About</div>
        <p className="sidebar-about">
          Powered by Claude AI (Anthropic). Supports 10 Indian languages. Ask about crops, soil,
          weather, pests, government schemes, or market prices.
        </p>
      </div>
    </aside>
  );
}
