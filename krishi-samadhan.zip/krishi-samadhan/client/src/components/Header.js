import React from 'react';
import './Header.css';
import { LANGUAGES } from '../utils/languages';
import { useAuth } from '../context/AuthContext';

export default function Header({ language, onLanguageChange }) {
  const { user, logout } = useAuth();

  return (
    <header className="header">
      <div className="header-logo">
        <div className="header-logo-icon">🌾</div>
        <div>
          <div className="header-logo-title">Krishi Samadhan</div>
          <div className="header-logo-sub">Agricultural AI Assistant</div>
        </div>
      </div>

      <div className="header-right">
        <div className="header-status">
          <div className="status-dot" />
          <span className="status-label">AI Active</span>
        </div>

        <select
          className="lang-select"
          value={language}
          onChange={(e) => onLanguageChange(e.target.value)}
          aria-label="Select language"
        >
          {LANGUAGES.map((l) => (
            <option key={l.code} value={l.code}>
              {l.native} ({l.name})
            </option>
          ))}
        </select>

        {user && (
          <button className="logout-btn" onClick={logout}>
            {user.name.split(' ')[0]} · Logout
          </button>
        )}
      </div>
    </header>
  );
}
