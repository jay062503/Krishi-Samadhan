import React from 'react';
import './MessageBubble.css';

function formatText(text) {
  if (!text) return '';
  // Bold
  let html = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  // Bullet lists
  html = html.replace(/^[•\-\*] (.+)/gm, '<li>$1</li>');
  const hasLi = html.includes('<li>');
  if (hasLi) {
    html = html.replace(/(<li>[\s\S]*?<\/li>(\n|$))+/g, (match) => `<ul>${match}</ul>`);
  }
  // Line breaks
  html = html.replace(/\n\n/g, '<br /><br />').replace(/\n/g, '<br />');
  return html;
}

export default function MessageBubble({ message }) {
  const { role, displayText, hasImage, timestamp } = message;
  const isUser = role === 'user';

  const time = timestamp
    ? new Date(timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    : '';

  return (
    <div className={`msg-row ${role}`}>
      <div className="msg-avatar">{isUser ? '👨‍🌾' : '🌱'}</div>
      <div className="msg-body">
        <div className="msg-bubble">
          {hasImage && (
            <span style={{ fontSize: '0.8rem', opacity: 0.7 }}>📷 Image uploaded · </span>
          )}
          {isUser ? (
            <span>{displayText}</span>
          ) : (
            <span dangerouslySetInnerHTML={{ __html: formatText(displayText) }} />
          )}
        </div>
        {time && <div className="msg-meta">{time}</div>}
      </div>
    </div>
  );
}
