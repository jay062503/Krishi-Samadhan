const Anthropic = require('@anthropic-ai/sdk');
const Conversation = require('../models/Conversation');

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const LANG_NAMES = {
  en: 'English', hi: 'Hindi', mr: 'Marathi', pa: 'Punjabi',
  te: 'Telugu', ta: 'Tamil', kn: 'Kannada', gu: 'Gujarati',
  bn: 'Bengali', or: 'Odia', ml: 'Malayalam',
};

function buildSystemPrompt(language, location) {
  const langName = LANG_NAMES[language] || 'English';
  return `You are Krishi Samadhan, an expert agricultural AI assistant for Indian farmers.
Always respond in ${langName} (language code: ${language}).
${location ? `The farmer is located in: ${location}.` : ''}
You have deep expertise in:
- Crop cultivation, soil health, and agronomy for Indian conditions
- Pest and disease identification and treatment (organic and chemical)
- Weather-based farming advice
- Government schemes (PM-KISAN, Soil Health Card, PMFBY, MSP, e-NAM)
- Market prices and selling strategies
- Water and irrigation management
- Post-harvest handling and storage
- Animal husbandry

If an image is provided, analyze it carefully to identify plant diseases, pests, soil conditions, or crop health issues.
Be practical, empathetic, and specific. Give actionable advice. When relevant, mention approximate costs or dosages in Indian units (kg, bigha, acre, litre).
Use bullet points and clear sections for readability. Start responses warmly.`;
}

// POST /api/chat/message
const sendMessage = async (req, res) => {
  try {
    const { message, language, location, imageBase64, imageMediaType } = req.body;
    const userId = req.user._id;

    // Get or create conversation
    let conversation = await Conversation.findOne({ userId });
    if (!conversation) {
      conversation = new Conversation({ userId, language, location, messages: [] });
    } else {
      conversation.language = language || conversation.language;
      conversation.location = location || conversation.location;
    }

    // Build user content (multimodal if image)
    let userContent;
    const hasImage = !!(imageBase64 && imageMediaType);

    if (hasImage) {
      userContent = [
        {
          type: 'image',
          source: { type: 'base64', media_type: imageMediaType, data: imageBase64 },
        },
        { type: 'text', text: message || 'Please analyze this image and provide agricultural advice.' },
      ];
    } else {
      userContent = message;
    }

    // Build messages history for Claude (last 20 turns to stay within context)
    const historyForClaude = conversation.messages.slice(-20).map((m) => ({
      role: m.role,
      content: m.content,
    }));
    historyForClaude.push({ role: 'user', content: userContent });

    // Call Claude API
    const response = await client.messages.create({
      model: 'claude-sonnet-4-6',
      max_tokens: 1024,
      system: buildSystemPrompt(language, location),
      messages: historyForClaude,
    });

    const assistantReply = response.content.map((b) => b.text || '').join('');

    // Persist messages
    conversation.messages.push({
      role: 'user',
      content: userContent,
      displayText: message || '[Image uploaded]',
      hasImage,
    });
    conversation.messages.push({
      role: 'assistant',
      content: assistantReply,
      displayText: assistantReply,
    });
    await conversation.save();

    res.json({ reply: assistantReply, conversationId: conversation._id });
  } catch (err) {
    console.error('Chat error:', err.message);
    res.status(500).json({ message: err.message });
  }
};

// GET /api/chat/history
const getHistory = async (req, res) => {
  try {
    const conversation = await Conversation.findOne({ userId: req.user._id });
    if (!conversation) return res.json({ messages: [] });

    const messages = conversation.messages.map((m) => ({
      role: m.role,
      displayText: m.displayText,
      hasImage: m.hasImage,
      timestamp: m.timestamp,
    }));
    res.json({ messages, language: conversation.language, location: conversation.location });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// DELETE /api/chat/history
const clearHistory = async (req, res) => {
  try {
    await Conversation.findOneAndUpdate(
      { userId: req.user._id },
      { messages: [] }
    );
    res.json({ message: 'History cleared.' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

module.exports = { sendMessage, getHistory, clearHistory };
